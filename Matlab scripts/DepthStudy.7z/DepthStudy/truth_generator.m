%% Function that will generate Truth data structure for Depth analysis

% Struture title
var_title = "truth_data.mat";

% Truth values 
% VariableName.Scene# = {position x, position y, postion z; repeat for other objects}

scalingxz = 20;
scalingy  = 2;
scaling = [scalingxz, scalingy, scalingxz];

depth_truth.scene_01 = {0.1,0.1,0.2;
                        0.4,0.3,0.55;
                        0.8,0.6,0.65;
                        0.65,0.9,0.38};

depth_truth.scene_01 = applyscaling(depth_truth.scene_01, scaling);

depth_truth.scene_02 = {0.2,0.3,0.85;
                        0.6,0.5,0.28;
                        0.7,0.7,0.71;
                        0.3,0.9,0.45};

depth_truth.scene_02 = applyscaling(depth_truth.scene_02, scaling);

depth_truth.scene_03 = {0.15,0.15,0.63;
                        0.7,0.4,0.48;
                        0.25,0.5,0.3;
                        0.5,0.7,0.85};

depth_truth.scene_03 = applyscaling(depth_truth.scene_03, scaling);

depth_truth.scene_04 = {0.65,0.2,0.46;
                        0.18,0.4,0.32;
                        0.82,0.5,0.14;
                        0.47,0.8,0.78};

depth_truth.scene_04 = applyscaling(depth_truth.scene_04, scaling);

depth_truth.scene_05 = {0.8,0.1,0.18;
                        0.6,0.2,0.5;
                        0.7,0.55,0.83;
                        0.23,0.68,0.63};

depth_truth.scene_05 = applyscaling(depth_truth.scene_05, scaling);

depth_truth.scene_06 = {0.12,0.25,0.5;
                        0.72,0.4,0.72;
                        0.27,0.55,0.9;
                        0.62,0.65,0.32};

depth_truth.scene_06 = applyscaling(depth_truth.scene_06, scaling);

depth_truth.scene_07 = {0.4,0.4,0.62;
                        0.5,0.55,0.21;
                        0.7,0.68,0.45;
                        0.86,0.86,0.77};

depth_truth.scene_07 = applyscaling(depth_truth.scene_07, scaling);

depth_truth.scene_08 = {0.23,0.18,0.76;
                        0.34,0.31,0.35;
                        0.67,0.45,0.25;
                        0.46,0.68,0.55};

depth_truth.scene_08 = applyscaling(depth_truth.scene_08, scaling);

depth_truth.scene_09 = {0.43,0.36,0.11;
                        0.78,0.52,0.4;
                        0.11,0.72,0.68;
                        0.55,0.9,0.91};

depth_truth.scene_09 = applyscaling(depth_truth.scene_09, scaling);

depth_truth.scene_10 = {0.5,0.5,0.5;
                        0.92,0.62,0.9;
                        0.14,0.75,0.15;
                        0.8,0.93,0.36};

depth_truth.scene_10 = applyscaling(depth_truth.scene_10, scaling);

depth_truth.scene_11 = {0.42,0.24,0.35;
                        0.65,0.36,0.21;
                        0.21,0.67,0.74;
                        0.78,0.82,0.63};

depth_truth.scene_11 = applyscaling(depth_truth.scene_11, scaling);

depth_truth.scene_12 = {0.53,0.33,0.6;
                        0.64,0.52,0.17;
                        0.33,0.62,0.7;
                        0.43,0.78,0.36};

depth_truth.scene_12 = applyscaling(depth_truth.scene_12, scaling);

depth_truth.scene_13 = {0.71,0.1,0.36;
                        0.27,0.26,0.68;
                        0.48,0.49,0.42;
                        0.13,0.72,0.27};

depth_truth.scene_13 = applyscaling(depth_truth.scene_13, scaling);

depth_truth.scene_14 = {0.64,0.22,0.45;
                        0.32,0.35,0.9;
                        0.76,0.57,0.8;
                        0.44,0.68,0.11};

depth_truth.scene_14 = applyscaling(depth_truth.scene_14, scaling);

depth_truth.scene_15 = {0.61,0.22,0.6;
                        0.36,0.41,0.48;
                        0.51,0.56,0.1;
                        0.26,0.67,0.26};

depth_truth.scene_15 = applyscaling(depth_truth.scene_15, scaling);

depth_truth.scene_16 = {0.13,0.32,0.36;
                        0.27,0.45,0.24;
                        0.43,0.67,0.78;
                        0.58,0.77,0.52};

depth_truth.scene_16 = applyscaling(depth_truth.scene_16, scaling);

depth_truth.scene_17 = {0.18,0.13,0.63;
                        0.8,0.23,0.9;
                        0.9,0.76,0.25;
                        0.7,0.86,0.56};

depth_truth.scene_17 = applyscaling(depth_truth.scene_17, scaling);

depth_truth.scene_18 = {0.15,0.1,0.41;
                        0.56,0.23,0.22;
                        0.43,0.45,0.84;
                        0.76,0.82,0.53};

depth_truth.scene_18 = applyscaling(depth_truth.scene_18, scaling);

depth_truth.scene_19 = {0.37,0.1,0.47;
                        0.12,0.26,0.26;
                        0.63,0.78,0.37;
                        0.27,0.88,0.9};

depth_truth.scene_19 = applyscaling(depth_truth.scene_19, scaling);

depth_truth.scene_20 = {0.12,0.1,0.9;
                        0.25,0.21,0.21;
                        0.62,0.42,0.5;
                        0.42,0.9,0.6};

depth_truth.scene_20 = applyscaling(depth_truth.scene_20, scaling);


save(var_title,"depth_truth")


function [cellmat] = applyscaling(cellmat, scaling)
    cellmat(:,1) = cellfun(@(x)x.*scaling(1),cellmat(:,1),'un',0);
    cellmat(:,2) = cellfun(@(x)x.*scaling(2),cellmat(:,2),'un',0);
    cellmat(:,3) = cellfun(@(x)x.*scaling(3),cellmat(:,3),'un',0);
end